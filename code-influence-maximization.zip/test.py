a=.01
print a