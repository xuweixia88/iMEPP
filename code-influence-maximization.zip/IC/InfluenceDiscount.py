''' Implementation of degree discount heuristic [1] for Independent Cascade model
of influence propagation in graph G

[1] -- Wei Chen et al. Efficient influence maximization in Social Networks (algorithm 4)
'''
__author__ = 'ivanovsergey'
from priorityQueue import PriorityQueue as PQ  # priority queue
import networkx as nx
import numpy as np
def InfluenceDiscountIC(G, k, p=.01,alpha=0.8):
    ''' Finds initial set of nodes to propagate in Independent Cascade model (with priority queue)
    Input: G -- networkx graph object
    k -- number of nodes needed
    p -- propagation probability
    Output:
    S -- chosen k nodes
    '''
    S = []
    dd = PQ() # degree discount
    t = dict() # number of adjacent vertices that are in S
    tt = dict()
    d = dict() # degree of each vertex
    OS=[0.0]*6103

    CO = nx.clustering(G)
    with open('../OS.txt') as f:
        for line in f:
            n,m=line.split()
            OS[int(n)]=float(m)
    OS=np.array(OS)
    OS=OS/max(OS)
    # initialize degree discount
    for u in G.nodes():

        #d[u] = d[u] # each edge adds degree 1
        # d[u] = len(G[u]) # each neighbor adds degree 1
        #d[u] = sum([G[u][v]['weight'] * CO[v] for v in G[u]])
        d[u] =sum([G[u][v]['weight']  for v in G[u]])


    maxd=max(d.values())

    for u in G.nodes():
        #d[u]=alpha*d[u]/maxd+(1-alpha)*OS[u]
        dd.add_task(u, -alpha*(d[u]/maxd)-(1-alpha)*OS[u]) # add degree of each node
        #dd.add_task(u,-TPN[u])
        t[u] = 0
        tt[u]=0



    # add vertices to S greedily
    y=0
    essentialProtein = []
    with open('../combinedEssentialprotein.txt') as f:
        for line in f:
            essentialProtein.append(int(line.strip('\n').strip()))
    f.close()

    with open('../DD.txt','w') as f:
        for i in range(k):
            u, priority = dd.pop_item() # extract node with maximal degree discount
            if u in essentialProtein:
                y+=1
            f.write(str(i+1) + ',' + str(y) + '\n')
            S.append(u)

            for v in G[u]:
                if v not in S:
                    t[v]+=1
                    tt[v] += G[u][v]['weight']# increase number of selected neighbors
                    #ttt=alpha*tt[v]/maxd+(1-alpha)*OS[v]
                    #priority = d[v] - (G[u][v]['weight']*CO[v]+1)*t[v] - (d[v] - tt[v])*tt[v]*p # discount of degree
                    #priority = (1-t[v]*p)*(G[u][v]['weight']*CO[v]+(d[v]-tt[v])*p)
                    #priority=(d[v]-tt[v])-(G[u][v]['weight']*CO[v]+(d[v]-tt[v])*t[v]*p)
                    #priority = ((1-p) ** t[v]) * (1 + (d[v] - tt[v])) * alpha + OS[v] * (1 - alpha)
                    priority = (d[v]-tt[v]-(d[v]-tt[v])*t[v]*p)/maxd* alpha + OS[v] * (1 - alpha)
                    #dd.add_task(v, -priority)
                    dd.add_task(v,-priority)

    return S

def degreeDiscountIC2(G, k, p=.01):
    ''' Finds initial set of nodes to propagate in Independent Cascade model (without priority queue)
    Input: G -- networkx graph object
    k -- number of nodes needed
    p -- propagation probability
    Output:
    S -- chosen k nodes
    Note: the routine runs twice slower than using PQ. Implemented to verify results
    '''
    d = dict()
    dd = dict() # degree discount
    t = dict() # number of selected neighbors
    S = [] # selected set of nodes
    for u in G:
        d[u] = sum([G[u][v]['weight'] for v in G[u]]) # each edge adds degree 1
        # d[u] = len(G[u]) # each neighbor adds degree 1
        dd[u] = d[u]
        t[u] = 0
    for i in range(k):
        u, ddv = max(dd.iteritems(), key=lambda (k,v): v)
        dd.pop(u)
        S.append(u)
        for v in G[u]:
            if v not in S:
                t[v] += G[u][v]['weight'] # increase number of selected neighbors
                dd[v] = d[v] - 2*t[v] - (d[v] - t[v])*t[v]*p
    return S

def degreeDiscountStar(G,k,p=.01):

    S = []
    scores = PQ()
    d = dict()
    t = dict()
    for u in G:
        d[u] = sum([G[u][v]['weight'] for v in G[u]])
        t[u] = 0
        score = -((1-p)**t[u])*(1+(d[u]-t[u])*p)
        scores.add_task(u, )
    for iteration in range(k):
        u, priority = scores.pop_item()
        print iteration, -priority
        S.append(u)
        for v in G[u]:
            if v not in S:
                t[v] += G[u][v]['weight']
                score = -((1-p)**t[u])*(1+(d[u]-t[u])*p)
                scores.add_task(v, score)
    return S


if __name__ == '__main__':
    console = []
