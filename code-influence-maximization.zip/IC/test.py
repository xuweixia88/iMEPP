__author__ = 'ivanovsergey'
import networkx as nx
import pandas as pd
import numpy as np
import random
from IC import runIC
from degreeDiscount import degreeDiscountIC
from InfluenceDiscount import InfluenceDiscountIC
from generalGreedy import generalGreedy
import matplotlib.pyplot as plt

import os

if __name__ == '__main__':
    import time

    start = time.time()
    i = 0
    PCC = [[0.0]*6103]*6103
    OS = [0.0] * 6103
    # read in graph
    G = nx.Graph()
    yeast = pd.read_csv('../data/GOFeature.csv')
    cc=yeast['cc']
    mf=yeast['mf']
    bp = yeast['bp']
    ecc = yeast['ecc']
    pcc = yeast['pcc']



    with open('../data/PPI_network.txt') as f:
        for line in f:
            u, v = map(int, line.split())
            #G.add_edge(u, v, weight=(t*ecc[i]+(1-t)*bp[i])*pcc[i])
            # G.add_edge(u, v, weight=pcc[i]*bp[i])
            # i += 1
            try:
                G[u][v]['weight'] += 1
            except:
                G.add_edge(u,v, weight=1)



    print 'Built graph G'
    #print time.time() - start


    #calculate initial set
    seed_size = 100
    S = degreeDiscountIC(G, seed_size)
    #S = InfluenceDiscountIC(G, seed_size, alpha=0.8)
    #S=generalGreedy(G, seed_size)
    print 'Initial set of', seed_size, 'nodes chosen'
    #print 'runtime', time.time() - start

    # write results S to file
    with open('visualisation.txt', 'w') as f:
        for node in S:
            f.write(str(node) + '\n')

    list1 = []

    with open('../data/combinedEssentialprotein.txt') as f1:
        for line in f1:
            list1.append(int(line.strip('\n').strip()))

    count = 0
    for protein in S:
        if protein in list1:
            count += 1

    print 'num of essential proteins is', count



    nodes=[u for u in G.nodes()]
    for u in nodes:
        if u not in S:
            G.remove_node(u)

    colors=[ 20 if u in list1 else 1 for u in G.nodes()]
    pos = nx.spring_layout(G)
    fig = plt.figure()
    ax = fig.add_subplot(111)
    ax.set(title='The protein interaction network for the top 100 selected proteins by IMEPP')
    nx.draw(G, pos, node_color=colors, node_size=80)
    plt.show()
    plt.savefig("ba.png", bbox_inches='tight')



