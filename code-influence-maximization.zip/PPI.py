proteinId={}
with open('./proteinID.txt') as f:
    for line in f:
        u, v = line.split()
        proteinId[v]=u

with open('./graphdata/PPI_network.txt') as f:
    n, m = f.readline().split()
    with open('./PPI_network.txt','w') as f1:
        for line in f:
            u, v = line.split()
            f1.write(proteinId[u]+' '+proteinId[v]+'\n')