from __future__ import division
import networkx as nx
import pandas as pd
import matplotlib.pylab as plt
from LT import *
import time, os
from greedy import *
from LDAG import *
from copy import deepcopy

if __name__ == "__main__":

    start = time.time()
    yeast = pd.read_csv('../GOFeature.csv')
    bp = yeast['bp']
    ecc = yeast['ecc']
    pcc = yeast['pcc']
    i = 0
    with open('../PPI_network.txt') as f:
        G = nx.DiGraph()
        for line in f:
            u, v = map(int, line.split())
            try:
                G[u][v]['weight'] = 1
            except KeyError:
                G.add_edge(u, v, weight=1)
            try:
                G[v][u]['weight'] = 1
            except KeyError:
                G.add_edge(v, u, weight=1)
            i += 1
    '''
    with open('../graphdata/hep.txt') as f:
        n, m = map(int, f.readline().split())
        G = nx.DiGraph()
        for line in f:
            u, v = map(int, line.split())
            try:
                G[u][v]['weight'] += 1
            except KeyError:
                G.add_edge(u,v,weight=1)
            try:
                G[v][u]['weight'] += 1
            except KeyError:
                G.add_edge(v,u,weight=1)
    '''
    print 'Built Graph G'
    print time.time() - start

    Ewu = uniformWeights(G)
    Ewr = randomWeights(G)
    print 'Found edge weights'
    print time.time() - start

    # find seed set
    S = LDAG_heuristic(G, Ewr, 100, 1.0/320)
    print 'Found seed set'
    print time.time() - start

    with open('LDAG.txt', 'w') as f:
        for node in S:
            f.write(str(node) + os.linesep)

    print 'Finding spread for S...'
    print avgLT(G, S, Ewr, 2000)

    console = []
    #num of Essentialprotein
    list1 = []

    with open('../combinedEssentialprotein.txt') as f1:
        for line in f1:
            list1.append(int(line.strip('\n').strip()))

    count = 0
    for protein in S:
        if protein in list1:
            count += 1

    print 'num of essential proteins is', count