import networkx as nx
import numpy as np
import pandas as pd
protein=[]
TPN=[0.0]*6103
OGN=[0.0]*6103
genedict={}
genemat=[]
proteinID={}
proteinID1={}
OS=[0.0]*6103

with open('./proteinID.txt') as f:
    for line in f:
        n, m = line.split()
        proteinID[int(n)] = m
        proteinID1[m]=int(n)

with open('./graphdata/geneexpressiondata.txt') as f:
    for line in f:
        gene = line.split()
        geneData=[]
        for i in range(len(gene)):
            if i > 1:
                geneData.append(float(gene[i]))
        genedict[gene[1]]=geneData
        genemat.append(geneData)
genemat=np.array(genemat)
avggene=list(np.mean(genemat, axis=0) )
G = nx.Graph()
with open('./PCC.txt', 'w') as f1:
    with open('./PPI_network.txt') as f:

        for line in f:
            u, v = map(int, line.split())
            x=genedict.get(proteinID.get(u))
            y=genedict.get(proteinID.get(v))
            if x and y :
                X = np.vstack([x, y])
                pcc=np.corrcoef(X)[0][1]
            else:
                pcc = 0
            G.add_edge(u,v, weight=pcc)


            f1.write(str(u) + ' ' + str(v) + ' ' + str(G[u][v]['weight']) + '\n')


'''
CO = nx.clustering(G)
s=0
cnt=0
for u in G.nodes():
    TPN[u]=sum([G[u][v]['weight']*CO[v] for v in G[u]])
    
with open('./PCC.txt','w') as f1:
    with open('./PPI_network.txt') as f:
        for line in f:
            u, v = map(int, line.split())
            x=genedict.get(proteinID.get(u))
            y=genedict.get(proteinID.get(v))
            if not x :
                x=avggene
            if not y:
                y=avggene
            X = np.vstack([x, y])
            f1.write(str(u)+' '+str(v)+' '+str(np.corrcoef(X)[0][1])+'\n')
            TPN[u] += np.corrcoef(X)[0][1] * CO[v]
            TPN[v] += np.corrcoef(X)[0][1] * CO[u]

avgpcc=float(s)/cnt
with open('./PPI_network.txt') as f:
    for line in f:
        u, v = map(int, line.split())
        x=genedict.get(proteinID.get(u))
        y=genedict.get(proteinID.get(v))
        if not x:
            TPN[u] += avgpcc * CO[v]
            X = np.vstack([x, y])
        elif not y:
            TPN[v] += avgpcc * CO[u]
'''
with open('./OS.txt','w') as f1:
    with open('./graphdata/protein_allorthology.txt') as f:
        ind, proName,num = f.readline().split()
        for line in f:
            i,j,k=line.split()
            id=proteinID1.get(j)
            if id:
                OS[id]=int(k)
                f1.write(str(id)+' '+k+'\n')
OS=np.array(OS)
OS=OS/max(OS)
'''
alpha=0.3
with open('./proteinID.txt') as f:
    for line in f:
        n, m = line.split()
        u=int(n)
        OGN[u]=alpha*OS[u]+(1-alpha)*(TPN[u]/max(TPN))

print(max(TPN))
with open('./OGN1.txt','w') as f:
    with open('./proteinID.txt') as f1:
        for line in f1:
            n, m = line.split()
            f.write(str(n)+' '+str(OGN[int(n)])+'\n')
'''


