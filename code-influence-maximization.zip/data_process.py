'''import os
proteinNum=set()
with open('./graphdata/PPI_network.txt') as f:
    n, m = f.readline().split()
    for line in f:
        u, v = line.split()
        proteinNum.add(u)
        proteinNum.add(v)

with open('./proteinID.txt','w') as f:
    i = 0
    for protein in proteinNum:
        f.write(str(i)+' '+protein + '\n')
        i+=1

proteinID={}
with open('./proteinID.txt') as f:
    for line in f:
        n,m = line.split()
        proteinID[m]=n

with open('./graphdata/combinedEssentialprotein.txt') as f:
    p = f.readline().split()
    with open('./combinedEssentialprotein.txt','w') as f1:
        for line in f:
            line = line.strip('\n').strip()
            if(proteinID.get(line)):
                f1.write(proteinID.get(line)+'\n')
'''
import networkx as nx
import numpy as np
import pandas as pd
protein=[]
genedict={}
proteinID={}

with open('./proteinID.txt') as f:
    for line in f:
        n, m = line.split()
        proteinID[int(n)] = m

with open('./graphdata/geneexpressiondata.txt') as f:
    for line in f:
        gene = line.split()
        geneData=[]
        for i in range(len(gene)):
            if i > 1:
                geneData.append(float(gene[i]))
        genedict[gene[1]]=geneData

G = nx.Graph()
with open('./PPI_network.txt') as f:
    n, m = f.readline().split()
    for line in f:
        u, v = map(int, line.split())
        try:
            G[u][v]['weight'] += 1
        except:
            G.add_edge(u,v, weight=1)
            # G.add_edge(u, v, weight=1)


with open('./PPI_network.txt') as f:
    n, m = f.readline().split()
    for line in f:
        u, v = map(int, line.split())
        x=genedict.get(proteinID.get(u))
        y=genedict.get(proteinID.get(v))
        if x and y:
            eccs=len(list(nx.common_neighbors(G, u, y)))/min(G.degree(x)-1,G.degree(y)-1)
            X = np.vstack([x, y])
            pccs = np.corrcoef(X)[0][1]
            print pccs
            try:
                G[u][v]['weight'] += pccs*eccs
            except:
                G.add_edge(u, v, weight=0)







